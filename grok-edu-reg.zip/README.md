# grok-edu-reg

**Single-file** tool: create **edu mail** (GetEduMail + temp mail) → register **xAI / Grok**.

> Personal / educational use only. You are responsible for complying with GetEduMail, xAI, and local law. Do not use for spam or abuse.

## Requirements

- Node.js 18+
- Google Chrome (recommended) or Playwright Chromium
- Windows tested; should work on macOS/Linux with minor path tweaks

## Install

```bash
cd grok-edu-reg
npm install
copy config.example.json config.json   # Windows
# cp config.example.json config.json  # macOS/Linux
```

Optional proxy list:

```text
# proxies.txt  (one per line)
host:port:user:pass
http://user:pass@host:port
```

## Run

```bash
# Chrome user profile + remote debugging (best login quality)
npm run reg

# Always create a new edu mail
npm run reg:fresh

# Reuse last edu from acc/latest.json
npm run reg:reuse

# Isolated Playwright browser (optional --proxy)
npm run reg:pw

# Multi
node reg.mjs --count 3 --yes
```

Flags:

| Flag | Meaning |
|------|---------|
| `--yes` / `-y` | No prompts |
| `--fresh` | Always new edu mail |
| `--reuse` | Use `acc/latest.json` |
| `--playwright` / `--pw` | Playwright profile (not Chrome user) |
| `--headless` | Headless Playwright |
| `--proxy host:port:user:pass` | Proxy (Playwright mode) |
| `--no-proxy` | Skip proxy |
| `--cdp http://127.0.0.1:9222` | Attach existing Chrome debug |
| `--domain example.edu` | Edu domain override |
| `--count N` | Sequential N regs |

## Flow

```
1. Temp mail     tempmail.lol → Guerrilla → mail.tm
2. GetEduMail    register → OTP → verify → claim @edu
3. Grok signup   email → OTP from edu inbox → profile → captcha → complete
4. Save          acc/latest.json + acc/results.jsonl
```

## Config (`config.json`)

| Key | Default | Notes |
|-----|---------|-------|
| `domain` / `domains` | `iunp.edu.rs` | Edu claim domain(s) |
| `randomName` | `true` | Random first/last from built-in list |
| `name` | `Alex Kowalski` | Fixed name if `randomName=false` |
| `password` | `""` | Empty = random password |
| `autoClickCaptcha` | `true` | Try Turnstile auto-click |
| `proxy` | `""` | Prefer this proxy line |

## Safety / public package

This package is intentionally **stripped**:

- No API keys, tokens, or accounts baked in
- No third-party “router” / OAuth push integrations
- No personal IMAP / Gmail app passwords
- Results only under local `acc/` (gitignored)

Do **not** commit `config.json`, `proxies.txt`, or `acc/`.

## Exit codes

| Code | Meaning |
|------|---------|
| `0` | Reg OK |
| `2` | Reg incomplete / fail |
| `3` | OTP fail |
| `4` | Email step fail |
| `5` | OTP type fail |
| `6` | Profile step fail |
| `1` | Other error |

## License / liability

Provided as-is. Authors are not responsible for misuse or ToS violations.
