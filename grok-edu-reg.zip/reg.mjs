#!/usr/bin/env node
/**
 * grok-edu-reg — single-file public package
 *
 * Flow:
 *   temp mail (lol → guerrilla → mail.tm)
 *   → GetEduMail register + OTP + claim edu
 *   → xAI / Grok signup (Chrome CDP or Playwright)
 *
 *   node reg.mjs --yes
 *   node reg.mjs --fresh --yes
 *   node reg.mjs --reuse --yes
 *   node reg.mjs --playwright --proxy host:port:user:pass
 *   node reg.mjs --count 3 --yes
 *
 * No secrets, no third-party OAuth push, no personal IMAP.
 * Personal / educational use only — respect GetEduMail & xAI ToS.
 */
import {
  readFileSync,
  writeFileSync,
  existsSync,
  mkdirSync,
  rmSync,
  readdirSync,
} from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";
import { execSync, spawn } from "child_process";
import { randomBytes } from "crypto";
import { chromium } from "playwright";

const __dir = dirname(fileURLToPath(import.meta.url));
const ACC_DIR = join(__dir, "acc");
const LATEST_PATH = join(ACC_DIR, "latest.json");
const RESULTS_JSONL = join(ACC_DIR, "results.jsonl");
const CONFIG_PATH = join(__dir, "config.json");
const PROXIES_FILE = join(__dir, "proxies.txt");
const PROFILE_DIR = join(__dir, ".pw-profile");
const EDU_API = "https://api.getedumail.com";
const MAILTM = "https://api.mail.tm";
const TEMPMAIL_LOL = "https://api.tempmail.lol";
const GUERRILLA = "https://api.guerrillamail.com/ajax.php";
const SIGNUP_URL = "https://accounts.x.ai/sign-up";
const CDP_DEFAULT = "http://127.0.0.1:9222";

const NAMES = [
  "Alex Kowalski", "Jordan Lee", "Sam Rivera", "Casey Morgan",
  "Riley Chen", "Avery Brooks", "Quinn Harper", "Jamie Soto",
  "Taylor Kim", "Morgan Blake", "Reese Parker", "Cameron Diaz",
  "Drew Nolan", "Skyler Hayes", "Finley Ross", "Rowan Ellis",
];

const args = process.argv.slice(2);
const flag = (name, def = null) => {
  const i = args.indexOf(name);
  return i >= 0 && args[i + 1] != null ? args[i + 1] : def;
};
const has = (n) => args.includes(n);
const YES = has("--yes") || has("-y");
const REUSE = has("--reuse");
const FRESH = has("--fresh");
const NO_PROXY = has("--no-proxy");
const AUTO_CLOSE = has("--auto-close") || has("--count") || has("-n");
const PLAYWRIGHT = has("--playwright") || has("--pw");
const USER_CHROME = !PLAYWRIGHT;
const HEADLESS = has("--headless");
const COUNT = Math.max(1, parseInt(flag("--count", flag("-n", "1")), 10) || 1);
const CDP = flag("--cdp", USER_CHROME ? CDP_DEFAULT : null);
const DOMAIN_CLI = flag("--domain", null);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const randUser = () =>
  randomBytes(8).toString("base64url").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 10);
const randPass = () => randomBytes(10).toString("base64url") + "A1!";

const C = {
  dim: (s) => `\x1b[2m${s}\x1b[0m`,
  bold: (s) => `\x1b[1m${s}\x1b[0m`,
  green: (s) => `\x1b[32m${s}\x1b[0m`,
  yellow: (s) => `\x1b[33m${s}\x1b[0m`,
  red: (s) => `\x1b[31m${s}\x1b[0m`,
  cyan: (s) => `\x1b[36m${s}\x1b[0m`,
};
const log = (...a) => console.log(C.dim("[reg]"), ...a);
const logOk = (...a) => console.log(C.dim("[reg]"), C.green("✓"), ...a);
const logWarn = (...a) => console.log(C.dim("[reg]"), C.yellow("!"), ...a);
const logErr = (...a) => console.log(C.dim("[reg]"), C.red("✗"), ...a);
const logPhase = (t) => console.log(`\n${C.cyan("──")} ${C.bold(t)} ${C.cyan("────")}`);

function loadConfig() {
  if (!existsSync(CONFIG_PATH)) return {};
  try {
    return JSON.parse(readFileSync(CONFIG_PATH, "utf8"));
  } catch {
    return {};
  }
}

function pickName(cfg) {
  if (cfg.randomName === false && cfg.name) return cfg.name;
  return NAMES[Math.floor(Math.random() * NAMES.length)];
}

function pickDomain(cfg) {
  if (DOMAIN_CLI) return DOMAIN_CLI.replace(/^@/, "");
  const list = [
    ...(Array.isArray(cfg.domains) ? cfg.domains : []),
    cfg.domain,
  ]
    .map((d) => String(d || "").trim().toLowerCase())
    .filter(Boolean);
  const uniq = [...new Set(list)];
  if (!uniq.length) return "iunp.edu.rs";
  return uniq[Math.floor(Math.random() * uniq.length)];
}

// ── GetEduMail API ──────────────────────────────────────────

async function eduApi(method, path, { token, body } = {}) {
  const headers = {
    "content-type": "application/json",
    accept: "application/json",
  };
  if (token) headers.cookie = `userToken=${token}`;
  const res = await fetch(EDU_API + path, {
    method,
    headers,
    body: body != null ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    json = { raw: text.slice(0, 400) };
  }
  return { status: res.status, ok: res.ok, json, text };
}

function extractCode(raw) {
  const t = String(raw || "");
  const markers = [
    /letter-spacing:\s*8px[\s\S]{0,80}?([0-9]{6})/i,
    /Courier New[\s\S]{0,120}?([0-9]{6})/i,
    /font-size:\s*32px[\s\S]{0,80}?([0-9]{6})/i,
  ];
  for (const re of markers) {
    const m = t.match(re);
    if (m) return m[1];
  }
  const plain = t
    .replace(/\r\n/g, "\n")
    .replace(/=\n/g, "")
    .replace(/=([0-9A-Fa-f]{2})/g, (_, h) =>
      String.fromCharCode(parseInt(h, 16))
    );
  for (const re of markers) {
    const m = plain.match(re);
    if (m) return m[1];
  }
  return (plain.match(/\b(\d{6})\b/) || [])[1] || null;
}

function htmlToText(html) {
  return String(html || "")
    .replace(/=\n/g, "")
    .replace(/=([0-9A-Fa-f]{2})/g, (_, h) =>
      String.fromCharCode(parseInt(h, 16))
    )
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(p|tr|div)>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n))
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

// ── Temp mail multi-provider ────────────────────────────────

async function createLolMailbox(logFn) {
  const r = await fetch(`${TEMPMAIL_LOL}/v2/inbox/create`, {
    method: "POST",
    headers: { "content-type": "application/json", accept: "application/json" },
    body: "{}",
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.address || !j.token)
    throw new Error(`tempmail.lol ${r.status}`);
  logFn(`[temp:lol] ${j.address}`);
  return {
    provider: "tempmail.lol",
    address: j.address,
    token: j.token,
    domain: j.address.split("@")[1] || "",
    list: async () => {
      const ir = await fetch(
        `${TEMPMAIL_LOL}/v2/inbox?token=${encodeURIComponent(j.token)}`
      );
      const ij = await ir.json().catch(() => ({}));
      if (ij.expired) throw new Error("tempmail.lol expired");
      return (ij.emails || []).map((m) => ({
        subject: m.subject || "",
        from: m.from || "",
        blob: [m.subject, m.body, m.text, m.html, m.preview]
          .filter(Boolean)
          .join("\n"),
      }));
    },
  };
}

async function createGuerrillaMailbox(logFn) {
  const agent = `grok-edu-reg/${randUser().slice(0, 6)}`;
  let r = await fetch(
    `${GUERRILLA}?f=get_email_address&ip=127.0.0.1&agent=${encodeURIComponent(agent)}`
  );
  let j = await r.json().catch(() => ({}));
  if (!r.ok || !j.sid_token) throw new Error(`guerrilla get ${r.status}`);
  let sid = j.sid_token;
  const user = `u${randUser().slice(0, 8)}`;
  r = await fetch(
    `${GUERRILLA}?f=set_email_user&email_user=${encodeURIComponent(user)}&sid_token=${encodeURIComponent(sid)}&lang=en`
  );
  j = await r.json().catch(() => ({}));
  sid = j.sid_token || sid;
  const address = j.email_addr || `${user}@guerrillamailblock.com`;
  logFn(`[temp:guerrilla] ${address}`);
  const box = {
    provider: "guerrilla",
    address,
    sid,
    domain: address.split("@")[1] || "",
    seq: 0,
  };
  box.list = async () => {
    const cr = await fetch(
      `${GUERRILLA}?f=check_email&sid_token=${encodeURIComponent(box.sid)}&seq=${box.seq || 0}`
    );
    const cj = await cr.json().catch(() => ({}));
    if (cj.sid_token) box.sid = cj.sid_token;
    const out = [];
    for (const m of cj.list || []) {
      if (m.mail_id == null) continue;
      const fr = await fetch(
        `${GUERRILLA}?f=fetch_email&sid_token=${encodeURIComponent(box.sid)}&email_id=${m.mail_id}`
      );
      const full = await fr.json().catch(() => null);
      if (!full) continue;
      out.push({
        subject: full.mail_subject || m.mail_subject || "",
        from: full.mail_from || "",
        blob: [full.mail_subject, full.mail_body, m.mail_excerpt]
          .filter(Boolean)
          .join("\n"),
      });
    }
    return out;
  };
  return box;
}

async function createMailTmMailbox(logFn) {
  const dr = await fetch(`${MAILTM}/domains`, {
    headers: { accept: "application/json" },
  });
  if (!dr.ok) throw new Error(`mail.tm domains ${dr.status}`);
  const dj = await dr.json().catch(() => ({}));
  const members = dj["hydra:member"] || [];
  const domains = members.map((d) => d.domain || d).filter(Boolean);
  if (!domains.length) throw new Error("mail.tm: no domains");
  const domain = domains[Math.floor(Math.random() * domains.length)];
  const address = `u${randUser().slice(0, 8)}@${domain}`;
  const password = randPass();
  let r = await fetch(`${MAILTM}/accounts`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ address, password }),
  });
  if (!r.ok) throw new Error(`mail.tm account ${r.status}`);
  r = await fetch(`${MAILTM}/token`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ address, password }),
  });
  const tok = await r.json().catch(() => ({}));
  if (!r.ok || !tok.token) throw new Error(`mail.tm token ${r.status}`);
  logFn(`[temp:mail.tm] ${address}`);
  return {
    provider: "mail.tm",
    address,
    token: tok.token,
    password,
    domain,
    list: async () => {
      const mr = await fetch(`${MAILTM}/messages`, {
        headers: { Authorization: `Bearer ${tok.token}` },
      });
      const mj = await mr.json().catch(() => ({}));
      const list = mj["hydra:member"] || [];
      const out = [];
      for (const m of list) {
        const full = await fetch(`${MAILTM}/messages/${m.id}`, {
          headers: { Authorization: `Bearer ${tok.token}` },
        })
          .then((x) => x.json())
          .catch(() => null);
        if (!full) continue;
        out.push({
          subject: full.subject || "",
          from: full.from?.address || "",
          blob: [
            full.subject,
            full.intro,
            full.text,
            typeof full.html === "string"
              ? full.html
              : JSON.stringify(full.html || ""),
          ].join("\n"),
        });
      }
      return out;
    },
  };
}

async function createTempMailbox(logFn = () => {}) {
  const providers = [
    createLolMailbox,
    createGuerrillaMailbox,
    createMailTmMailbox,
  ];
  const errors = [];
  for (const fn of providers) {
    try {
      return await fn(logFn);
    } catch (e) {
      const msg = String(e.message || e).slice(0, 100);
      errors.push(msg);
      logFn(`[temp] skip — ${msg}`);
    }
  }
  throw new Error(`temp mail all failed: ${errors.join(" | ")}`);
}

async function waitTempCode(tm, { timeoutMs = 90_000, onTick } = {}) {
  const t0 = Date.now();
  let i = 0;
  while (Date.now() - t0 < timeoutMs) {
    onTick?.(i++);
    try {
      const messages = await tm.list();
      for (const m of messages) {
        if (/welcome to guerrilla/i.test(m.subject || "")) continue;
        const code = extractCode(m.blob);
        if (code) return { code, subject: m.subject || "" };
      }
    } catch (e) {
      if (/expired/i.test(String(e.message || e))) throw e;
    }
    await sleep(2000);
  }
  throw new Error(`temp OTP timeout (${tm.provider}: ${tm.address})`);
}

// ── Create edu account ──────────────────────────────────────

async function createEduAccount({ domain, name, password, logFn = log } = {}) {
  const fullName = name || "Alex Kowalski";
  const username = randUser();
  const eduEmail = `${username}@${domain}`;
  const pass = password || randPass();

  logFn(`[1] Temp mail`);
  const tm = await createTempMailbox(logFn);
  const registerEmail = tm.address;
  logFn(`[1] provider=${tm.provider}`);

  logFn(`[2] Register GetEduMail = ${registerEmail}`);
  let r = await eduApi("POST", "/getedumail/user/register", {
    body: { name: fullName, email: registerEmail, password: pass },
  });
  let token = r.json?.userToken || null;
  let needOtp = true;
  let code = "";

  if (!r.ok) {
    logFn(`[2] exists → login`);
    r = await eduApi("POST", "/getedumail/user/login", {
      body: { email: registerEmail, password: pass },
    });
    if (!r.ok) throw new Error(`login ${r.status}: ${r.text?.slice(0, 120)}`);
    token = r.json?.userToken || null;
    if (!token) throw new Error("no userToken from login");
    needOtp = false;
  } else if (!token) throw new Error("no userToken");

  if (needOtp) {
    logFn(`[3] OTP send`);
    r = await eduApi("GET", "/getedumail/user/otp", { token });
    if (!r.ok) throw new Error(`otp send ${r.status}`);
    logFn(`[4] Wait OTP…`);
    const otp = await waitTempCode(tm, {
      onTick: (i) => logFn(`[4] poll ${i + 1}`),
    });
    code = otp.code;
    logFn(`[4] Code ${code}`);
    logFn(`[5] Verify`);
    for (const otpVal of [code, Number(code)]) {
      r = await eduApi("POST", "/getedumail/user/verify-otp", {
        token,
        body: { otp: otpVal },
      });
      if (r.ok) break;
    }
    if (!r.ok) throw new Error(`verify-otp ${r.status}`);
    if (r.json?.userToken) token = r.json.userToken;
  }

  logFn(`[6] Claim ${eduEmail}`);
  let claimed = null;
  for (const body of [
    { email: eduEmail },
    { username, domain },
    { email: eduEmail, username, domain },
  ]) {
    r = await eduApi("POST", "/getedumail/emails", { token, body });
    if (r.ok || r.status === 201) {
      claimed = true;
      break;
    }
  }
  if (!claimed) {
    r = await eduApi("POST", "/getedumail/emails/claim", {
      token,
      body: { email: eduEmail },
    });
    if (!(r.ok || r.status === 201))
      throw new Error(`claim ${r.status}: ${r.text?.slice(0, 120)}`);
  }
  logFn(`[6] Claimed`);

  const acc = {
    email: eduEmail,
    loginEmail: registerEmail,
    password: pass,
    fullName,
    userToken: token,
    domain,
    code: needOtp ? code : "",
    claimedAt: new Date().toISOString(),
    via: `temp-${tm.provider}`,
  };
  saveEduAcc(acc);
  logFn(`[saved] ${eduEmail}`);
  return acc;
}

function ensureAccDir() {
  mkdirSync(ACC_DIR, { recursive: true });
}

function saveEduAcc(acc) {
  ensureAccDir();
  writeFileSync(LATEST_PATH, JSON.stringify(acc, null, 2));
  const n =
    readdirSync(ACC_DIR).filter((f) => /^\d+\.json$/.test(f)).length + 1;
  writeFileSync(join(ACC_DIR, `${n}.json`), JSON.stringify({ ...acc, id: n }, null, 2));
  return n;
}

function loadLatestEdu() {
  if (!existsSync(LATEST_PATH)) return null;
  try {
    return JSON.parse(readFileSync(LATEST_PATH, "utf8"));
  } catch {
    return null;
  }
}

async function loginForToken(email, password) {
  if (!email || !password) return null;
  const r = await eduApi("POST", "/getedumail/user/login", {
    body: { email, password },
  });
  if (!r.ok) return null;
  return r.json?.userToken || null;
}

async function listEduInbox(email, token) {
  const r = await eduApi(
    "GET",
    `/getedumail/emails/${encodeURIComponent(email)}/list?page=1`,
    { token }
  );
  if (!r.ok) throw new Error(`inbox ${r.status}: ${r.text?.slice(0, 100)}`);
  return r.json?.emails || [];
}

function extractXaiCode(text, subject = "") {
  const t = `${subject}\n${text || ""}`;
  const m =
    t.match(/\b([A-Z0-9]{2,4}-[A-Z0-9]{2,6})\b/) ||
    subject.match(/\b([A-Z0-9]{2,4}-[A-Z0-9]{2,6})\b/) ||
    t.match(/\b(\d{6})\b/);
  return m ? m[1] : null;
}

function isXaiMail(m) {
  const blob = `${m.subject || ""} ${JSON.stringify(m.from || "")}`.toLowerCase();
  return /x\.ai|xai|noreply@x\.ai|confirmation code|spacexai/.test(blob);
}

async function pollEduOtp(email, token, { password, logFn = log } = {}) {
  let tok = token;
  let authTried = false;
  for (let i = 0; i < 60; i++) {
    let mails = [];
    try {
      mails = await listEduInbox(email, tok);
    } catch (e) {
      const msg = e.message || "";
      logFn(`[otp] ${msg.slice(0, 80)}`);
      if (!authTried && password && /403|401|inbox/i.test(msg)) {
        authTried = true;
        const fresh = await loginForToken(email, password);
        if (fresh) {
          tok = fresh;
          continue;
        }
      }
      await sleep(400);
      continue;
    }
    for (const m of mails) {
      if (!isXaiMail(m)) continue;
      const body = htmlToText(m.body?.text || m.body?.html || "");
      const code = extractXaiCode(body, m.subject || "");
      if (code) {
        logFn(`[otp] ${code} ← ${m.subject}`);
        return { code, userToken: tok };
      }
    }
    process.stdout.write(i % 15 === 14 ? "\n" : ".");
    await sleep(400);
  }
  console.log("");
  throw new Error("Timeout: no xAI OTP in edu inbox");
}

// ── Proxy (optional, Playwright only) ───────────────────────

function parseProxyLine(line) {
  const s = String(line || "").trim();
  if (!s || s.startsWith("#")) return null;
  if (/^https?:\/\//i.test(s)) {
    try {
      const u = new URL(s);
      return {
        server: `${u.protocol}//${u.hostname}:${u.port || 80}`,
        username: decodeURIComponent(u.username || ""),
        password: decodeURIComponent(u.password || ""),
        url: s,
        raw: s,
      };
    } catch {
      return null;
    }
  }
  const parts = s.split(":");
  if (parts.length < 2) return null;
  const [host, port, user, ...rest] = parts;
  const password = rest.join(":") || "";
  const username = user || "";
  const url =
    username || password
      ? `http://${encodeURIComponent(username)}:${encodeURIComponent(password)}@${host}:${port}`
      : `http://${host}:${port}`;
  return { server: `http://${host}:${port}`, username, password, url, raw: s };
}

function resolveProxy(cfg) {
  if (NO_PROXY) return null;
  const cli = flag("--proxy", null);
  if (cli === "0" || cli === "off") return null;
  const candidates = [];
  if (cli) candidates.push(parseProxyLine(cli));
  if (cfg.proxy) candidates.push(parseProxyLine(cfg.proxy));
  if (existsSync(PROXIES_FILE)) {
    for (const line of readFileSync(PROXIES_FILE, "utf8").split(/\r?\n/)) {
      candidates.push(parseProxyLine(line));
    }
  }
  return candidates.find(Boolean) || null;
}

function toPwProxy(p) {
  if (!p) return undefined;
  const opt = { server: p.server };
  if (p.username) opt.username = p.username;
  if (p.password) opt.password = p.password;
  return opt;
}

// ── Chrome CDP ──────────────────────────────────────────────

function chromePaths() {
  const local = process.env.LOCALAPPDATA || "";
  const pf = process.env["PROGRAMFILES"] || "C:\\Program Files";
  const pf86 = process.env["PROGRAMFILES(X86)"] || "C:\\Program Files (x86)";
  const home = process.env.HOME || process.env.USERPROFILE || "";
  const exes = [
    join(pf, "Google", "Chrome", "Application", "chrome.exe"),
    join(pf86, "Google", "Chrome", "Application", "chrome.exe"),
    join(local, "Google", "Chrome", "Application", "chrome.exe"),
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/usr/bin/google-chrome",
    "/usr/bin/chromium",
  ].filter((p) => existsSync(p));
  const userData =
    flag("--chrome-user-data", null) ||
    (process.platform === "win32"
      ? join(local, "Google", "Chrome", "User Data")
      : process.platform === "darwin"
        ? join(home, "Library", "Application Support", "Google", "Chrome")
        : join(home, ".config", "google-chrome"));
  return { exe: exes[0] || "chrome", userData };
}

async function cdpAlive(url = CDP_DEFAULT) {
  try {
    const r = await fetch(url.replace(/\/$/, "") + "/json/version", {
      signal: AbortSignal.timeout(1500),
    });
    return r.ok;
  } catch {
    return false;
  }
}

function chromeRunning() {
  if (process.platform !== "win32") return false;
  try {
    const out = execSync('tasklist /FI "IMAGENAME eq chrome.exe" /NH', {
      encoding: "utf8",
      windowsHide: true,
      timeout: 5000,
    });
    return /chrome\.exe/i.test(out) && !/No tasks|INFO:/i.test(out);
  } catch {
    return false;
  }
}

function launchChromeDebug(exe, userData, port) {
  if (process.platform === "win32") {
    const ps = [
      `$p = Start-Process -FilePath ${JSON.stringify(exe)}`,
      `-ArgumentList @(`,
      `  '--remote-debugging-port=${port}',`,
      `  '--remote-debugging-address=127.0.0.1',`,
      `  '--user-data-dir=${userData.replace(/'/g, "''")}',`,
      `  '--no-first-run',`,
      `  '--no-default-browser-check',`,
      `  'about:blank'`,
      `) -PassThru; Write-Output $p.Id`,
    ].join(" ");
    try {
      execSync(`powershell -NoProfile -Command ${JSON.stringify(ps)}`, {
        encoding: "utf8",
        windowsHide: true,
        timeout: 15000,
      });
      return;
    } catch {
      /* fall through */
    }
  }
  const child = spawn(
    exe,
    [
      `--remote-debugging-port=${port}`,
      `--remote-debugging-address=127.0.0.1`,
      `--user-data-dir=${userData}`,
      "--no-first-run",
      "--no-default-browser-check",
      "about:blank",
    ],
    { detached: true, stdio: "ignore" }
  );
  child.unref();
}

async function ensureUserChromeCdp(cdpUrl = CDP_DEFAULT) {
  const prefer = cdpUrl || CDP_DEFAULT;
  const port = (prefer.match(/:(\d+)/) || [])[1] || "9222";
  const { exe, userData } = chromePaths();
  if (await cdpAlive(prefer)) {
    log(`CDP ready ${prefer}`);
    return prefer;
  }
  if (chromeRunning()) {
    throw new Error(
      `Chrome is running without CDP on ${prefer}.\n` +
        `  Close Chrome, then re-run (script will open with --remote-debugging-port=${port}).`
    );
  }
  if (!existsSync(userData)) {
    logWarn(`User Data missing: ${userData} — still launching`);
  }
  log(`launch Chrome debug :${port}`);
  launchChromeDebug(exe, userData, port);
  for (let i = 0; i < 60; i++) {
    await sleep(500);
    if (await cdpAlive(prefer)) {
      logOk(`CDP OK ${(i + 1) * 0.5}s`);
      return prefer;
    }
  }
  throw new Error(`CDP not up: ${prefer}`);
}

// ── Browser helpers ─────────────────────────────────────────

function safePageUrl(page) {
  try {
    return page.url() || "";
  } catch {
    return "";
  }
}

function isNavDestroyed(e) {
  return /Execution context was destroyed|Target closed|Session closed|frame was detached|navigat/i.test(
    String(e?.message || e || "")
  );
}

function detectFromUrl(url) {
  const u = String(url || "");
  const onSignup = /sign-up|sign_up|signup|register/i.test(u);
  const onSignin = /sign-in|sign_in|login/i.test(u) && !onSignup;
  const onApp =
    !onSignup &&
    /grok\.x\.ai|console\.x\.ai|\/chat|\/home|\/c\/|welcome|accounts\.x\.ai\/(account|settings)/i.test(
      u
    );
  if (onApp) return { step: "done", url: u.slice(0, 120) };
  if (onSignup) return { step: "signup", url: u.slice(0, 120) };
  if (onSignin) return { step: "signin", url: u.slice(0, 120) };
  return null;
}

async function detectPage(page) {
  const url0 = safePageUrl(page);
  const urlHit = detectFromUrl(url0);
  if (urlHit?.step === "done") {
    return {
      step: "done",
      url: urlHit.url,
      hasEmailInput: false,
      hasPassword: false,
      hasFirst: false,
      hasLast: false,
      hasOtp: false,
      hasSignupEmailBtn: false,
      hasComplete: false,
      captcha: false,
      err: false,
      errSnippet: "",
    };
  }
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      if (attempt > 0) await sleep(50);
      return await page.evaluate(() => {
        const url = location.href;
        const text = (document.body?.innerText || "").slice(0, 6000);
        const lower = text.toLowerCase();
        const visible = (el) => {
          if (!el) return false;
          const s = getComputedStyle(el);
          if (s.display === "none" || s.visibility === "hidden" || s.opacity === "0")
            return false;
          const r = el.getBoundingClientRect();
          return r.width > 2 && r.height > 2;
        };
        const inputs = [...document.querySelectorAll("input")].filter(visible);
        const buttons = [
          ...document.querySelectorAll("button,[role='button'],a"),
        ].filter(visible);
        const btnText = (b) => (b.innerText || b.textContent || "").trim();
        const hasEmailInput = inputs.some(
          (i) =>
            i.type === "email" ||
            /email/i.test(i.name + i.id + i.autocomplete + i.placeholder)
        );
        const hasPassword = inputs.some(
          (i) =>
            i.type === "password" ||
            /password/i.test(i.name + i.id + i.autocomplete)
        );
        const hasFirst = inputs.some((i) =>
          /first|given/i.test(i.name + i.id + i.autocomplete + i.placeholder)
        );
        const hasLast = inputs.some((i) =>
          /last|family|surname/i.test(
            i.name + i.id + i.autocomplete + i.placeholder
          )
        );
        const otpInputs = inputs.filter((i) => {
          if (i.type === "password" || i.type === "email" || i.type === "hidden")
            return false;
          const meta = `${i.name} ${i.id} ${i.autocomplete} ${i.placeholder} ${i.inputMode}`;
          if (/otp|one.?time|verif|code|pin/i.test(meta)) return true;
          if (i.maxLength > 0 && i.maxLength <= 2) return true;
          if (i.inputMode === "numeric" && !/phone|tel/i.test(meta)) return true;
          return false;
        });
        const hasOtp =
          otpInputs.length >= 1 &&
          !hasPassword &&
          (/verif|confirm|code|one.?time|enter the code|check your email/i.test(
            lower
          ) ||
            otpInputs.length >= 4);
        const hasSignupEmailBtn = buttons.some((b) =>
          /^sign up with email$/i.test(btnText(b))
        );
        const hasComplete = buttons.some((b) =>
          /complete sign up|create (your )?account/i.test(btnText(b))
        );
        const turnstileIframe = [...document.querySelectorAll("iframe")].some(
          (f) => /turnstile|challenges\.cloudflare/i.test(f.src || f.title || "")
        );
        const cfToken = [
          ...document.querySelectorAll(
            'input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"]'
          ),
        ].some((i) => (i.value || "").length > 20);
        const err =
          /something went wrong|try again|already (been )?registered|email (is )?already|invalid (email|code)|too many|blocked|suspended|rate limit/i.test(
            text
          );
        const onSignup = /sign-up|sign_up|signup|register/i.test(url);
        const onSignin = /sign-in|sign_in|login/i.test(url) && !onSignup;
        const onApp =
          !onSignup &&
          !onSignin &&
          /grok\.x\.ai|console\.|\/chat|\/home|\/c\//i.test(url);

        let step = "unknown";
        if (onApp) step = "done";
        else if (
          /start chatting|go to grok|open grok|welcome to grok/i.test(lower) &&
          !hasEmailInput
        )
          step = "done";
        else if (hasOtp) step = "otp";
        else if (
          hasPassword &&
          (hasFirst || hasLast || hasComplete || turnstileIframe)
        )
          step = "profile";
        else if (hasEmailInput && onSignup) step = "email";
        else if (hasSignupEmailBtn || onSignup) step = "chooser";
        else if (onSignin) step = "signin";

        return {
          step,
          url: url.slice(0, 120),
          hasEmailInput,
          hasPassword,
          hasFirst,
          hasLast,
          hasOtp,
          hasSignupEmailBtn,
          hasComplete,
          captcha: !!(turnstileIframe || cfToken),
          err: !!err,
          errSnippet: err
            ? text.match(
                /[^\n]{0,40}(already|invalid|blocked|wrong|limit)[^\n]{0,40}/i
              )?.[0] || ""
            : "",
        };
      });
    } catch (e) {
      const url = safePageUrl(page);
      const fromUrl = detectFromUrl(url);
      if (fromUrl?.step === "done" || isNavDestroyed(e)) {
        return {
          step:
            fromUrl?.step === "done" || !/sign-up|signup|sign-in/i.test(url)
              ? "done"
              : fromUrl?.step || "unknown",
          url: url.slice(0, 120),
          hasEmailInput: false,
          hasPassword: false,
          hasFirst: false,
          hasLast: false,
          hasOtp: false,
          hasSignupEmailBtn: false,
          hasComplete: false,
          captcha: false,
          err: false,
          errSnippet: "",
        };
      }
      if (attempt < 2 && isNavDestroyed(e)) continue;
      return {
        step: fromUrl?.step || "unknown",
        url: url.slice(0, 120),
        hasEmailInput: false,
        hasPassword: false,
        hasFirst: false,
        hasLast: false,
        hasOtp: false,
        hasSignupEmailBtn: false,
        hasComplete: false,
        captcha: false,
        err: !isNavDestroyed(e),
        errSnippet: String(e.message || e).slice(0, 80),
      };
    }
  }
  return { step: "unknown", url: safePageUrl(page).slice(0, 120), err: true };
}

async function waitStep(page, want, { timeoutMs = 15_000, pollMs = 150 } = {}) {
  const set = new Set(Array.isArray(want) ? want : [want]);
  const t0 = Date.now();
  let last = "";
  while (Date.now() - t0 < timeoutMs) {
    const d = await detectPage(page);
    if (`${d.step}` !== last) {
      log(`step=${d.step}${d.err ? " ERR" : ""}`);
      last = d.step;
    }
    if (set.has(d.step)) return d;
    await sleep(pollMs);
  }
  return detectPage(page);
}

async function fillReact(page, loc, value) {
  const want = String(value ?? "");
  await loc.waitFor({ state: "visible", timeout: 5000 }).catch(() => {});
  await loc.click({ timeout: 3000 }).catch(() => {});
  await loc.fill("").catch(() => {});
  await page.keyboard.press("Control+A").catch(() => {});
  await page.keyboard.press("Backspace").catch(() => {});
  await loc.evaluate((el, v) => {
    el.focus();
    const proto =
      el.tagName === "TEXTAREA"
        ? HTMLTextAreaElement.prototype
        : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, "value");
    if (desc?.set) desc.set.call(el, "");
    else el.value = "";
    el.dispatchEvent(new Event("input", { bubbles: true }));
    if (desc?.set) desc.set.call(el, v);
    else el.value = v;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }, want);
  let got = await loc.inputValue().catch(() => "");
  if (got !== want) {
    await loc.click().catch(() => {});
    await page.keyboard.press("Control+A").catch(() => {});
    await page.keyboard.press("Backspace").catch(() => {});
    await page.keyboard.type(want, { delay: 25 });
    got = await loc.inputValue().catch(() => "");
  }
  return got === want || got.length === want.length;
}

async function fillFirst(page, selectors, value) {
  for (const sel of selectors) {
    const loc = page.locator(sel).first();
    if (!(await loc.count().catch(() => 0))) continue;
    if (!(await loc.isVisible().catch(() => false))) continue;
    try {
      const ok = await fillReact(page, loc, value);
      if (ok) return true;
      const got = await loc.inputValue().catch(() => "");
      if (got && got.length === String(value).length) return true;
    } catch {
      /* next */
    }
  }
  return false;
}

async function clickFirst(page, names) {
  for (const name of names) {
    const btn = page.getByRole("button", { name });
    if (await btn.count().catch(() => 0)) {
      try {
        await btn.first().click({ timeout: 3000 });
        return true;
      } catch {
        /* next */
      }
    }
  }
  return false;
}

function isXaiCookie(c) {
  const d = String(c.domain || "")
    .toLowerCase()
    .replace(/^\./, "");
  return (
    /(^|\.)x\.ai$/i.test(d) ||
    /grok/i.test(d) ||
    /auth\.x\.ai/i.test(d) ||
    /accounts\.x\.ai/i.test(d)
  );
}

async function clearXaiSession(page, context) {
  try {
    const cookies = await context.cookies().catch(() => []);
    const drop = cookies.filter(isXaiCookie);
    const cdp = await context.newCDPSession(page).catch(() => null);
    if (cdp) {
      for (const c of drop) {
        try {
          await cdp.send("Network.deleteCookies", {
            name: c.name,
            domain: c.domain,
            path: c.path || "/",
          });
        } catch {
          /* */
        }
      }
      for (const origin of [
        "https://accounts.x.ai",
        "https://grok.x.ai",
        "https://auth.x.ai",
        "https://x.ai",
      ]) {
        try {
          await cdp.send("Storage.clearDataForOrigin", {
            origin,
            storageTypes:
              "cookies,local_storage,session_storage,indexeddb,cache_storage",
          });
        } catch {
          /* */
        }
      }
      log(`cleared ${drop.length} xAI cookies`);
    } else if (drop.length) {
      await context.clearCookies();
    }
  } catch (e) {
    logWarn(`clear session: ${String(e.message || e).slice(0, 60)}`);
  }
}

async function logoutXai(page, context) {
  log("logout xAI…");
  await clearXaiSession(page, context);
  for (const u of [
    "https://accounts.x.ai/sign-out",
    "https://accounts.x.ai/logout",
  ]) {
    try {
      await page.goto(u, { waitUntil: "domcontentloaded", timeout: 4000 });
    } catch {
      /* */
    }
  }
  await clearXaiSession(page, context);
  try {
    await page.goto(SIGNUP_URL, {
      waitUntil: "domcontentloaded",
      timeout: 15000,
    });
  } catch {
    /* */
  }
}

// ── Signup steps ────────────────────────────────────────────

async function fillSignupEmail(page, email) {
  await clickFirst(page, [/accept all cookies|accept all|reject all/i]).catch(
    () => {}
  );
  for (let attempt = 1; attempt <= 2; attempt++) {
    let d = await detectPage(page);
    log(`email-step try=${attempt} now=${d.step}`);
    if (["otp", "profile", "done"].includes(d.step)) return true;

    if (
      d.step === "chooser" ||
      d.hasSignupEmailBtn ||
      (d.step === "unknown" && !d.hasEmailInput)
    ) {
      const alt = page.getByRole("button", {
        name: /sign up with email|with email/i,
      });
      if (await alt.count())
        await alt.first().click({ timeout: 2500 }).catch(() => {});
      else {
        await page
          .evaluate(() => {
            const b = [...document.querySelectorAll("button,a")].find((el) =>
              /sign up with email/i.test(el.innerText || "")
            );
            if (b) b.click();
          })
          .catch(() => {});
      }
      d = await waitStep(page, ["email", "otp", "profile", "chooser"], {
        timeoutMs: 5000,
      });
    }

    if (d.step !== "email" && !d.hasEmailInput) {
      if (attempt === 1) {
        await page.goto(SIGNUP_URL, {
          waitUntil: "domcontentloaded",
          timeout: 30000,
        });
        continue;
      }
      return false;
    }

    const ok = await fillFirst(
      page,
      [
        'input[type="email"]',
        'input[name="email"]',
        'input[autocomplete="email"]',
        'input[placeholder*="mail" i]',
        'input[id*="email" i]',
      ],
      email
    );
    if (!ok) return false;
    log(`email filled: ${email}`);
    await page.keyboard.press("Enter").catch(() => {});
    d = await waitStep(page, ["otp", "profile", "email", "error"], {
      timeoutMs: 10000,
    });
    if (d.step === "email" && !d.err) {
      await clickFirst(page, [
        /^sign up$/i,
        /^continue$/i,
        /^next$/i,
        /^submit$/i,
      ]);
      d = await detectPage(page);
    }
    if (d.step === "otp" || d.step === "profile") return true;
    if (d.err) {
      logErr(`email ERR: ${d.errSnippet || "?"}`);
      return false;
    }
    if (d.step === "email" && attempt < 2) continue;
    return false;
  }
  return false;
}

async function typeOtp(page, code) {
  const raw = String(code || "").replace(/\s/g, "");
  let d = await waitStep(page, ["otp", "profile", "done"], { timeoutMs: 6000 });
  if (d.step === "profile" || d.step === "done") return true;
  const otpLoc = page.locator(
    'form input:not([type="password"]):not([type="email"]):not([type="hidden"]):visible'
  );
  const nOtp = await otpLoc.count().catch(() => 0);
  log(`otp code=${raw} inputs=${nOtp}`);
  if (nOtp < 1) {
    logWarn(`CODE = ${raw} — paste manually if needed`);
    return false;
  }
  if (nOtp === 1 || raw.includes("-")) {
    await otpLoc.first().click();
    await page.keyboard.press("Control+A").catch(() => {});
    await page.keyboard.type(raw, { delay: 50 });
  } else {
    const chars = raw.replace(/-/g, "").split("");
    for (let i = 0; i < Math.min(chars.length, nOtp); i++) {
      await otpLoc.nth(i).fill(chars[i]);
    }
  }
  d = await detectPage(page);
  if (d.step === "otp") {
    await clickFirst(page, [
      /confirm email|verify email|^verify$|^confirm$|^continue$|^next$|^submit$/i,
    ]);
    d = await waitStep(page, ["profile", "done", "otp"], { timeoutMs: 8000 });
  }
  return d.step === "profile" || d.step === "done" || d.step === "otp";
}

async function fillProfileStep(page, first, last, password) {
  let d = await waitStep(page, ["profile", "done", "otp"], { timeoutMs: 6000 });
  if (d.step === "done") return true;
  if (d.step === "otp") return false;
  if (d.step !== "profile" && !d.hasPassword) {
    d = await waitStep(page, ["profile", "done"], { timeoutMs: 6000 });
    if (d.step !== "profile" && !d.hasPassword) return false;
  }
  if (d.hasFirst || d.step === "profile") {
    await fillFirst(
      page,
      ['input[name*="first" i]', 'input[autocomplete="given-name"]'],
      first || "Alex"
    );
  }
  if (d.hasLast || d.step === "profile") {
    await fillFirst(
      page,
      ['input[name*="last" i]', 'input[autocomplete="family-name"]'],
      last || "Kowalski"
    );
  }
  const passOk = await fillFirst(
    page,
    [
      'input[type="password"]:visible',
      'input[name="password"]:visible',
      'input[autocomplete="new-password"]:visible',
      'input[type="password"]',
    ],
    password
  );
  if (!passOk) {
    const pw = page.locator('input[type="password"]').first();
    await pw.click().catch(() => {});
    await page.keyboard.type(String(password), { delay: 30 });
  }
  logOk(`profile filled`);
  return true;
}

async function turnstileState(page) {
  try {
    const url = page.url();
    if (
      !/sign-up|signup/i.test(url) &&
      /grok\.x\.ai|console|\/chat|\/home/i.test(url)
    ) {
      return { success: true, len: 99, viaNav: true, failed: false };
    }
  } catch {
    /* */
  }
  try {
    return await page.evaluate(() => {
      const inputs = [
        ...document.querySelectorAll(
          'input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"]'
        ),
      ];
      const token =
        inputs.map((i) => i.value).find((v) => v && v.length > 20) || "";
      const text = document.body?.innerText || "";
      const failed = /Verification failed|Error:\s*Invalid/i.test(text);
      const iframes = [...document.querySelectorAll("iframe")];
      const iframeOk = iframes.some((f) =>
        /success|verified|complete|passed/i.test(
          `${f.title || ""} ${f.getAttribute("aria-label") || ""}`
        )
      );
      const uiOk = /Success!|verified you are human/i.test(text);
      return {
        token: token.slice(0, 32),
        len: token.length,
        failed,
        success: !failed && (token.length > 20 || iframeOk || uiOk),
        viaNav: false,
      };
    });
  } catch (e) {
    if (isNavDestroyed(e))
      return { success: true, len: 99, viaNav: true, failed: false };
    return { success: false, len: 0, failed: false, viaNav: false };
  }
}

async function clickSignupAfterCaptcha(page, { maxWaitMs = 20_000 } = {}) {
  const patterns = [
    /complete sign up/i,
    /create (your )?account/i,
    /^continue$/i,
    /^submit$/i,
  ];
  const t0 = Date.now();
  while (Date.now() - t0 < maxWaitMs) {
    const st = await turnstileState(page).catch(() => null);
    if (st?.viaNav) return { ok: true, reason: "already-nav" };
    if (st?.failed) return { ok: false, reason: "failed" };
    if (st?.success || (st?.len || 0) > 20) {
      for (const re of patterns) {
        const loc = page.getByRole("button", { name: re });
        if (!(await loc.count().catch(() => 0))) continue;
        const b = loc.first();
        if (await b.isDisabled().catch(() => true)) continue;
        if (!(await b.isVisible().catch(() => false))) continue;
        try {
          await b.click({ timeout: 8000 });
        } catch (e) {
          if (isNavDestroyed(e)) return { ok: true, reason: "click-nav" };
        }
        await sleep(500);
        const url = safePageUrl(page);
        if (!/sign-up|signup/i.test(url)) return { ok: true, reason: "nav" };
        return { ok: true, reason: "clicked" };
      }
    }
    await sleep(120);
  }
  return { ok: false, reason: "timeout" };
}

async function handleCaptchaAndComplete(page, cfg) {
  let d = await detectPage(page);
  if (d.step === "done") return { ok: true, via: "already-done" };

  const autoClick = cfg.autoClickCaptcha !== false;
  log(`captcha step=${d.step} widget=${!!d.captcha} auto=${autoClick}`);

  await page
    .evaluate(() => {
      if (window.turnstile?.execute) {
        try {
          window.turnstile.execute();
        } catch {
          /* */
        }
      }
    })
    .catch(() => {});

  let token = "";
  for (let i = 0; i < 40 && !token; i++) {
    token = await page
      .evaluate(
        () =>
          [
            ...document.querySelectorAll(
              'input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"]'
            ),
          ]
            .map((el) => el.value)
            .find((v) => v && v.length > 20) || ""
      )
      .catch(() => "");
    if (!token) await sleep(200);
  }

  if (!token && autoClick) {
    log("click Turnstile…");
    for (let attempt = 0; attempt < 15 && !token; attempt++) {
      await page
        .evaluate(() => {
          if (window.turnstile?.execute) {
            try {
              window.turnstile.execute();
            } catch {
              /* */
            }
          }
        })
        .catch(() => {});
      try {
        const ifr = page.locator(
          'iframe[src*="turnstile"], iframe[src*="challenges.cloudflare"]'
        );
        const box = await ifr.first().boundingBox().catch(() => null);
        if (box && box.width > 10) {
          await page.mouse.click(box.x + 26, box.y + Math.min(box.height / 2, 35), {
            delay: 25,
          });
        }
      } catch {
        /* */
      }
      await sleep(300);
      token = await page
        .evaluate(
          () =>
            [
              ...document.querySelectorAll(
                'input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"]'
              ),
            ]
              .map((el) => el.value)
              .find((v) => v && v.length > 20) || ""
        )
        .catch(() => "");
    }
  }

  log(`token len=${token.length}`);
  if (!(token && token.length > 20)) {
    const st = await turnstileState(page);
    if (!st.success && !st.viaNav) {
      logErr("captcha fail — solve manually if window is open");
      // wait a bit for manual
      const t0 = Date.now();
      while (Date.now() - t0 < 45000) {
        const st2 = await turnstileState(page);
        if (st2.success || st2.viaNav || st2.len > 20) break;
        d = await detectPage(page);
        if (d.step === "done") return { ok: true, via: "manual-done" };
        await sleep(500);
      }
    }
  }

  d = await detectPage(page);
  if (d.step === "done") return { ok: true, via: "done" };

  const clk = await clickSignupAfterCaptcha(page, { maxWaitMs: 15000 });
  if (clk.ok) logOk(`Complete: ${clk.reason}`);
  else logWarn(`Complete: ${clk.reason}`);

  // settle
  const t0 = Date.now();
  while (Date.now() - t0 < 12000) {
    const u = safePageUrl(page);
    if (u && !/sign-up|signup/i.test(u)) break;
    d = await detectPage(page);
    if (d.step === "done") break;
    await sleep(200);
  }
  d = await detectPage(page);
  if (d.step !== "done" && !/sign-up|signup/i.test(d.url || safePageUrl(page))) {
    d = { ...d, step: "done" };
  }
  return { ok: d.step === "done", via: clk.reason || "final", step: d.step };
}

// ── Launch browser ──────────────────────────────────────────

async function launchBrowser(proxy, cfg) {
  const headless = HEADLESS || cfg.headless === true;
  if (USER_CHROME && !headless) {
    const cdpUrl = await ensureUserChromeCdp(CDP || CDP_DEFAULT);
    log(`CDP attach ${cdpUrl}`);
    const browser = await chromium.connectOverCDP(cdpUrl);
    const context = browser.contexts()[0] || (await browser.newContext());
    const page = await context.newPage();
    try {
      await page.bringToFront();
    } catch {
      /* */
    }
    return { context, page, browser, userChrome: true };
  }

  log(headless ? "Playwright headless" : "Playwright headed");
  if (FRESH && existsSync(PROFILE_DIR)) {
    try {
      rmSync(PROFILE_DIR, { recursive: true, force: true });
    } catch {
      /* */
    }
  }
  mkdirSync(PROFILE_DIR, { recursive: true });
  const pwProxy = toPwProxy(proxy);
  if (pwProxy) log(`proxy ${pwProxy.server}`);

  const browser = await chromium.launch({
    headless,
    channel: headless ? undefined : "chrome",
    proxy: pwProxy,
    args: [
      "--disable-blink-features=AutomationControlled",
      "--no-sandbox",
      "--no-first-run",
    ],
  });
  const context = await browser.newContext({
    locale: "en-US",
    viewport: { width: 1366, height: 768 },
    userAgent:
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
  });
  await context.addInitScript(() => {
    Object.defineProperty(navigator, "webdriver", { get: () => false });
  });
  return {
    context,
    page: await context.newPage(),
    browser,
    userChrome: false,
  };
}

function saveResult(result) {
  ensureAccDir();
  writeFileSync(join(ACC_DIR, "grok-latest.json"), JSON.stringify(result, null, 2));
  writeFileSync(RESULTS_JSONL, JSON.stringify(result) + "\n", { flag: "a" });
  writeFileSync(
    join(ACC_DIR, `grok-${result.ok ? "ok" : "fail"}-${Date.now()}.json`),
    JSON.stringify(result, null, 2)
  );
}

// ── Main once ───────────────────────────────────────────────

async function runOnce() {
  const cfg = loadConfig();
  let acc;

  if (REUSE) {
    acc = loadLatestEdu();
    if (!acc?.email) throw new Error("No acc/latest.json — drop --reuse");
    log(`[reuse] ${acc.email}`);
    if (acc.password) {
      const t = await loginForToken(
        acc.loginEmail || acc.email,
        acc.password
      );
      if (t) acc.userToken = t;
    }
  } else {
    const name = pickName(cfg);
    const domain = pickDomain(cfg);
    logPhase("Edu mail");
    log(`domain=${domain} name=${name}`);
    let lastErr;
    for (let t = 1; t <= 3; t++) {
      try {
        acc = await createEduAccount({
          domain: pickDomain(cfg),
          name,
          password: cfg.password || undefined,
          logFn: log,
        });
        lastErr = null;
        break;
      } catch (e) {
        lastErr = e;
        logWarn(`edu try ${t}/3: ${String(e.message || e).slice(0, 120)}`);
        await sleep(1000 * t);
      }
    }
    if (lastErr) throw lastErr;
  }

  const grokPass =
    flag("--password", null) ||
    acc.password ||
    `Gx${Math.random().toString(36).slice(2, 10)}A1!`;

  const proxy =
    USER_CHROME && !HEADLESS ? null : resolveProxy(cfg);
  logPhase("Info");
  log(`edu   ${acc.email}`);
  log(`pass  ${grokPass}`);
  log(`mode  ${USER_CHROME && !HEADLESS ? "Chrome CDP" : "Playwright"}`);

  const { context, page, browser, userChrome } = await launchBrowser(
    proxy,
    cfg
  );

  logPhase("1/5 Session");
  try {
    await page.goto(SIGNUP_URL, {
      waitUntil: "domcontentloaded",
      timeout: 30000,
    });
  } catch {
    /* */
  }
  {
    const d1 = await detectPage(page);
    if (
      d1.step === "done" ||
      (d1.step !== "chooser" &&
        d1.step !== "email" &&
        !d1.hasEmailInput &&
        !d1.hasSignupEmailBtn)
    ) {
      log(`session step=${d1.step} → logout`);
      await logoutXai(page, context);
      await page
        .goto(SIGNUP_URL, { waitUntil: "domcontentloaded", timeout: 30000 })
        .catch(() => {});
    } else {
      log(`session clean step=${d1.step}`);
    }
  }

  logPhase("2/5 Email");
  let emailFilled = await fillSignupEmail(page, acc.email);
  if (!emailFilled) {
    await logoutXai(page, context);
    await page
      .goto(SIGNUP_URL, { waitUntil: "domcontentloaded", timeout: 30000 })
      .catch(() => {});
    emailFilled = await fillSignupEmail(page, acc.email);
  }
  if (!emailFilled) {
    logErr("email step fail");
    process.exitCode = 4;
    return { ok: false };
  }
  logOk("email submitted");

  logPhase("3/5 OTP");
  let otp = null;
  {
    const d = await detectPage(page);
    if (d.step === "profile" || d.step === "done") {
      log(`skip OTP — already ${d.step}`);
    } else {
      try {
        otp = await pollEduOtp(acc.email, acc.userToken, {
          password: acc.password,
          logFn: log,
        });
        if (otp.userToken) acc.userToken = otp.userToken;
      } catch (e) {
        logErr(e.message);
        const fresh = await loginForToken(
          acc.loginEmail || acc.email,
          acc.password
        );
        if (fresh) {
          try {
            otp = await pollEduOtp(acc.email, fresh, {
              password: acc.password,
              logFn: log,
            });
          } catch (e2) {
            logErr(e2.message);
          }
        }
        if (!otp?.code) {
          process.exitCode = 3;
          return { ok: false };
        }
      }
    }
  }

  logPhase("4/5 Profile");
  if (otp?.code) {
    logOk(`OTP ${otp.code}`);
    const otpOk = await typeOtp(page, otp.code);
    if (!otpOk) {
      const d = await detectPage(page);
      if (d.step !== "profile" && d.step !== "done") {
        process.exitCode = 5;
        return { ok: false };
      }
    }
  }
  const [first, ...rest] = String(pickName(cfg)).split(/\s+/);
  const profOk = await fillProfileStep(
    page,
    first || "Alex",
    rest.join(" ") || "Kowalski",
    grokPass
  );
  if (!profOk) {
    const d = await detectPage(page);
    if (d.step !== "done") {
      process.exitCode = 6;
      return { ok: false };
    }
  }

  logPhase("5/5 Captcha + Complete");
  const fin = await handleCaptchaAndComplete(page, cfg);
  const regOk = !!fin.ok;
  if (regOk) logOk("reg done");
  else logErr(`reg incomplete step=${fin.step || "?"}`);

  const result = {
    ok: regOk,
    email: acc.email,
    eduPassword: acc.password,
    grokPassword: grokPass,
    otp: otp?.code || null,
    step: fin.step || (regOk ? "done" : "unknown"),
    via: fin.via,
    at: new Date().toISOString(),
  };
  try {
    saveResult(result);
    logOk(`saved → acc/`);
  } catch (e) {
    logErr(`save: ${e.message}`);
  }

  if (!regOk) {
    await logoutXai(page, context).catch(() => {});
  } else {
    // leave session for user; optional logout with --logout
    if (has("--logout")) await logoutXai(page, context).catch(() => {});
  }

  console.log(`
${regOk ? C.green("══ OK ══") : C.red("══ FAIL ══")}
  email : ${acc.email}
  pass  : ${grokPass}
  step  : ${result.step}
`);

  if (userChrome) {
    await page.close({ runBeforeUnload: false }).catch(() => {});
  } else if (AUTO_CLOSE || COUNT > 1) {
    await context.close().catch(() => {});
    await browser?.close?.().catch(() => {});
  } else {
    log("close browser window to exit");
    await new Promise((resolve) => {
      context.on("close", resolve);
      browser?.on?.("disconnected", resolve);
    });
  }

  process.exitCode = regOk ? 0 : 2;
  return result;
}

async function main() {
  if (!existsSync(CONFIG_PATH) && existsSync(join(__dir, "config.example.json"))) {
    writeFileSync(
      CONFIG_PATH,
      readFileSync(join(__dir, "config.example.json"), "utf8")
    );
    log("created config.json from example");
  }
  let ok = 0;
  for (let i = 0; i < COUNT; i++) {
    if (COUNT > 1) logPhase(`Job ${i + 1}/${COUNT}`);
    try {
      const r = await runOnce();
      if (r?.ok) ok++;
    } catch (e) {
      logErr(String(e.message || e));
      if (COUNT === 1) process.exit(1);
    }
    if (i + 1 < COUNT) await sleep(1500);
  }
  if (COUNT > 1) console.log(`\nDone: ${ok}/${COUNT} OK`);
  process.exit(process.exitCode || (ok ? 0 : 1));
}

main();
